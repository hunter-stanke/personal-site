# -*- coding: utf-8 -*-
"""
Created on Wed Apr 18 15:28:53 2018

GEO869 ~ Geosimulation

Final Project Code

Hunter Stanke

    Main script that handles batch runs of CWD dispersal model
    
"""


from src import ASCII, deer, in_out
from shapely.geometry import MultiPoint

# Load Files
##=============================================================================
# =============================================================================
#Import forest distance file
forest_file = "./data/for_dist.asc"
forest = ASCII.Raster(forest_file)

#Import lulc file
ccap_file = "./data/ccap_rcl.asc"
ccap = ASCII.Raster(ccap_file)

#Import disease points
lns_pnts = "./data/lns_pnts.shp"
mntl_pnts = "./data/mntl_pnts.shp"

# Output files for frequency maps
flns_paths = "./results/lns_pths"
fmntl_paths = "./results/mntl_pths"

#Output files for density maps
flns_dns = "./results/dns_lns"
fmntl_dns = "./results/dns_mntl"

# Blank maps to track dispersals
fpath_map = "./data/blank90.tif"



##============================================================================
## INITIALIZATION
##============================================================================

#Input parameters
iterations = 1  # Number dispersals within points
ticks = 4000  # Number of steps within dispersal
buffer_width = 1000  # Distance to buffer bounding geometries that form disease zones

# Initialize deer
lns_deer = deer.generate_deer(lns_pnts)
mntl_deer = deer.generate_deer(mntl_pnts)

# Success Logs
success_lns_log = {} # Dictionary to hold success/failure data by point
success_mntl_log = {}


# Creates empty arrays to map travel
lns_paths = in_out.read_array(fpath_map)
mntl_paths = in_out.read_array(fpath_map) 
lns_dns = in_out.read_array(fpath_map)
mntl_dns = in_out.read_array(fpath_map)



# Defines Disease zone around Lansing points using covex hull bounding geometry and 1 km buffer
lns_zone_coords = [] # Coordinates for disease zone polygon
for ag in lns_deer:
    success_lns_log[ag.ID] = []
    coord = (ag.x, ag.y)
    lns_zone_coords.append(coord)
lns_zone = MultiPoint(lns_zone_coords).convex_hull  # Convex hull bounding geometry around disease points
lns_zone = lns_zone.buffer(buffer_width)  # Buffer polygon by 1000m

# Defines Disease zone around montcalm points using covex hull bounding geometry and 1 km buffer
mntl_zone_coords = []
for ag in mntl_deer:
    success_mntl_log[ag.ID] = []
    coord = (ag.x, ag.y)
    mntl_zone_coords.append(coord)
mntl_zone = MultiPoint(mntl_zone_coords).convex_hull
mntl_zone = mntl_zone.buffer(buffer_width)



##=============================================================================
## EXECUTION
##=============================================================================
# Main model batch runs. Produces multiple dispersals from each point
for i in range(iterations):
    
    #Generates new set of deer for each iteration
    lns_deer = deer.generate_deer(lns_pnts)
    mntl_deer = deer.generate_deer(mntl_pnts)
    
    # Disperses deer for defined number of steps
    for ag in lns_deer:
        for t in range(ticks): 
            neighbors = ag.neighborhood(ccap) # Requires raster input for indexing
            ag.move(neighbors, forest_layer = forest, lulc_layer = ccap)
            ag.check_sucess(mntl_zone)  #Checks if deer has entered opposite disease zone
            ag.update_maps(lns_paths, lns_dns, ccap)  # Zone level map
            
    for ag in mntl_deer:
        for t in range(ticks):
            neighbors = ag.neighborhood(ccap) # Requires raster input for indexing
            ag.move(neighbors, forest_layer = forest, lulc_layer = ccap)
            ag.check_sucess(lns_zone)  #Checks if deer has entered opposite disease zone
            ag.update_maps(mntl_paths, mntl_dns, ccap)  # Zone level map
            
        success_mntl_log[ag.ID].append(ag.success) #Doesn't require ag.ID-1 because calling dict key
        
#Export maps
in_out.out_tif(mntl_paths, fpath_map, fmntl_paths) # Save zone level map
in_out.out_tif(mntl_dns, fpath_map, fmntl_dns)
in_out.out_tif(lns_paths, fpath_map, flns_paths)
in_out.out_tif(lns_dns, fpath_map, flns_dns)


# Determine and print success rate by point for lansing deer
success_rates = deer.success_rate(success_lns_log, iterations)
for rate in success_rates:
    print(str(rate) + ": ", success_rates[rate])

# Determine and print success rate by point for montcalm deer    
success_rates = deer.success_rate(success_mntl_log, iterations)
for rate in success_rates:
    print(str(rate) + ": ", success_rates[rate])









