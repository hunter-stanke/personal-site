# -*- coding: utf-8 -*-
"""
Created on Wed Mar 28 21:44:27 2018

GEO869 ~ Geosimulation

Final Project Code

Hunter Stanke


    Script defines class Deer which represents deer agents and thier attributes in CWD dispersal model
"""
import random
from src import suitability
from osgeo import ogr
from shapely.geometry import Point
import statistics as s

class Deer:
    def __init__(self, point_shapefile):
        ''' 
        Represents deer agents
        ID = Unique id for each deer. Pulled from shapefile data
        X:  Current x coordinate of agent. Updated with each move. 
        Y:  Current y coordinate of agent. Updated with each move. 
        Active: True or false. Defines whether or not agent is still actively dispersing
        dist_travelled: Total distance of dispersal, updated with each time step.
        total_moves: number of time steps taken by agent
        pref_direction: Agent has a bias in movement, defines the order in which cells
            will be selected from neighborhood so that direction of first movement is preferred.
        memory: list containing direction of travel in past steps taken by the agent. Used to update
            pref_direction once a defined number of steps away from the start point
        success: True or false. Defines whether or not agent has reached opposite disease area. 
        
        '''
        self.ID = point_shapefile.GetField('Id')
        geom = point_shapefile.GetGeometryRef()
        Xmin = geom.GetX() - 500
        Xmax = geom.GetX() + 500
        Ymin = geom.GetY() - 500
        Ymax = geom.GetY() + 500
        self.x = random.uniform(Xmin, Xmax)
        self.y = random.uniform(Ymin, Ymax)
        self.active = True
        self.dist_travelled = 0
        self.total_moves = 0
        directions = ["NW", "N", "NE", "W", "E", "SW", "S", "SE"]
        choice = random.choice(directions)
        self.pref_direction = choice
        self.memory = [choice]
        self.success = False
        
        
    def __str__(self):
        """prints deer agent attributes"""
        deer_print = "Deer {}\nLocation: ({},{})\nActive: {}\nPreferred Direction: {}\nMemory: {}\nSuccess: {}\n".format(self.ID, self.x, self.y, self.active, self.pref_direction, self.memory, self.success)
        return deer_print
        

      
        
    def neighborhood(self, index_raster):
        '''
        Defines 3x3 agent neighborhood based on current position. 
        
        First and second choice: orders cells in nieghborhood so that cells in the preferred direction are chosen first
        Levels shuffled before being combined so that cells within level have equal likelihood of being chosen
        
        Current cell not included in neighborhood
        '''
        #Convert deer location (coordinate) to index in raster at that coordinate
        index = index_raster.xy_to_grid_loc(self.x, self.y)
        cell_row = index[0] 
        cell_col = index[1]

        #Create list levels of nighborhood based on agent preferred direction
        if self.pref_direction == "NW":
            first_choice = [(cell_row-1, cell_col-1), (cell_row-1, cell_col), (cell_row, cell_col-1), (cell_row+1, cell_col-1), (cell_row-1, cell_col+1)]
            second_choice = [(cell_row, cell_col+1), (cell_row+1, cell_col), (cell_row+1, cell_col+1)]
              
        if self.pref_direction == "N":
            first_choice = [(cell_row-1, cell_col-1), (cell_row-1, cell_col), (cell_row-1, cell_col+1), (cell_row, cell_col-1), (cell_row, cell_col+1)]
            second_choice = [(cell_row+1, cell_col-1), (cell_row+1, cell_col), (cell_row+1, cell_col+1)]
            
        if self.pref_direction == "NE":
            first_choice = [(cell_row-1, cell_col), (cell_row-1, cell_col+1), (cell_row, cell_col+1), (cell_row-1, cell_col-1), (cell_row+1, cell_col+1)]
            second_choice = [(cell_row, cell_col-1), (cell_row+1, cell_col-1), (cell_row+1, cell_col)]
            
        if self.pref_direction == "W":
            first_choice = [(cell_row-1, cell_col-1), (cell_row, cell_col-1), (cell_row+1, cell_col-1), (cell_row-1, cell_col), (cell_row+1, cell_col)]
            second_choice = [(cell_row-1, cell_col+1), (cell_row, cell_col+1), (cell_row+1, cell_col+1)]
            
        if self.pref_direction == "E": 
            first_choice = [(cell_row-1, cell_col+1), (cell_row, cell_col+1), (cell_row+1, cell_col+1), (cell_row-1, cell_col), (cell_row+1, cell_col)]
            second_choice = [(cell_row-1, cell_col-1), (cell_row, cell_col-1), (cell_row+1, cell_col-1)]
            
        if self.pref_direction == "SW":
            first_choice = [(cell_row, cell_col-1), (cell_row+1, cell_col-1), (cell_row+1, cell_col), (cell_row-1, cell_col-1), (cell_row+1, cell_col+1)]
            second_choice = [(cell_row-1, cell_col), (cell_row-1, cell_col+1), (cell_row, cell_col+1)]
                       
        if self.pref_direction == "S":
            first_choice = [(cell_row+1, cell_col-1), (cell_row+1, cell_col), (cell_row+1, cell_col+1), (cell_row, cell_col-1), (cell_row, cell_col+1)]
            second_choice = [(cell_row-1, cell_col-1), (cell_row-1, cell_col), (cell_row-1, cell_col+1)]
                       
        if self.pref_direction == "SE":
            first_choice = [(cell_row, cell_col+1), (cell_row+1, cell_col), (cell_row+1, cell_col+1), (cell_row+1, cell_col-1), (cell_row-1, cell_col+1)]
            second_choice = [(cell_row-1, cell_col-1), (cell_row-1, cell_col), (cell_row, cell_col-1)]

            
        #Shuffle levels independently so that deer has equal probability of choosing cell within level
        first_choice = random.sample(first_choice, len(first_choice))
        second_choice = random.sample(second_choice, len(second_choice))
            
        #Combine levels in choice order
        neighborhood = first_choice + second_choice
        return neighborhood
        
        
    
    
    def move(self, neighborhood, forest_layer, lulc_layer): 
        '''
        Evaluates neighborhood cells as defined by neighborhood function for movement suitability. 
    
        Moves agent to first cell that evaluates as suitable
        
        If an agent iterates through its entire neighborhood and fails to move, it remains in the current position
        
        Updates agent distance travelled and total moves
        '''
        if self.active == True: 
            
            last_location = (self.x, self.y)   #Saves current location of agent to test against updated location
            
            #Loop through all options in neighborhood
            for cell in neighborhood:
                forest_suitability = False    #Resets suitability test
                lulc_suitability = False
                cell_row = cell[0]
                cell_col = cell[1]
                forest_suitability = suitability.suitability_forest(cell_row, cell_col, forest_layer)
                lulc_suitability = suitability.suitability_lulc(cell_row, cell_col, lulc_layer)
                
                # If lulc and forest suitability evaluate True, the agent moves to that cell and stops evaluating neighborhood
                if forest_suitability == True and lulc_suitability == True:
                    coords = lulc_layer.grid_loc_to_xy(cell_row, cell_col) #raster required for indexing, coverts index to coords
                    self.x = coords[0]
                    self.y = coords[1]
                    break
            #Update distance travelled
            dist = pow(self.x - last_location[0], 2) + pow(self.y - last_location[1], 2)
            dist = pow(dist, 0.5)
            self.dist_travelled += dist
            #update total_moves
            self.total_moves += 1
# =============================================================================
#             # If agent does not move to a cell in neighborhood, it becomes inactive. Dispersal terminates
#             if last_location == (self.x, self.y):
#                 self.active = False
#                 
# =============================================================================
   
    
    def update_direction(self, cell, reference_raster):
        '''
        Only used inside of move() function above. Updates agent memory of direction travelled
        over last 11 time steps. 
        
        If total moves is less than 11, than the chosen direction is simply appended to memory
        If total moves is greater than 11, than chosen direction is appended to memory, and oldest
            move in memory is deleted.
            
        Updates preferred direction of agent by taking mode of memory. Therefor if an agent has 
            travelled NW in 6 of the last 11 steps, it's updated preferred direction will be NW
        '''
        #Agent location (x,y) to grid index
        index = reference_raster.xy_to_grid_loc(self.x, self.y)
        row = index[0]
        col = index[1]
        
        # Identifies direction of move
        if cell == (row-1, col-1):
            direction = "NW"
        if cell == (row-1, col):
            direction = "N"
        if cell == (row-1, col+1):
            direction = "NE"
        if cell == (row, col-1):
            direction = "W"
        if cell == (row, col+1):
            direction = "E"
        if cell == (row+1, col-1):
            direction = "SW"
        if cell == (row+1, col):
            direction = "S"
        if cell == (row+1, col+1):
            direction = "SE"
        
        self.memory.append(direction) # append newest move to memory
        
        if self.total_moves > 11: # delete oldest move in memory
            del self.memory[0]
            new_direction = s.mode(self.memory) # Updates preferred direction of agent based on mode of memory
            self.memory = new_direction 
            
                            
    def update_maps(self, path_map, dns_map, reference_raster):
        '''
        Increases the value of cell where agent is located by one
        
        When looped with agent moves, will produce a map of dispersals
        
        path_map and dns_map: start with blank array
        
        path_map: maps the cells in which agents have travelled. Does not consider multiple contacts with cell
        dns_map: maps cells in which agents habe travelled and contains count of contacts by cell
        
        reference_raster: from ASCII script. Used to convert agent coords to row, col
        '''
        if self.active == True:   #Only updates map if agent is active
            
            #Converts agent coords to row and col of grid
            index = reference_raster.xy_to_grid_loc(self.x, self.y)
            cell_row = index[0] 
            cell_col = index[1]
            
            # Update path map
            if path_map[cell_row, cell_col] < 1:
                path_map[cell_row, cell_col] +=1
                
            # Update density map
            dns_map[cell_row, cell_col] += 1

                
    
    def check_sucess(self, target_area):
        '''
        Checks if agent has reached opposite disease zone. If agent reaches zone, self.sucess = True permanently
        target_area: Shapley Polygon of opposite disease zone
        
        Uses Shapely to check if agent location is within the bounds of disease zone (polygon)
        '''
        
        if self.success == False:  # Only check if agent has not yet reached disease zone
            coord = (self.x, self.y)
            point = Point(coord) 
            test = point.within(target_area)
            if test:
                self.success = True #Update success if within bounds
                
                

def generate_deer(points):
    '''
    Generates a list of deer agents from a shapefile by calling Deer class 
    points: shapefile of disease deer locations
    '''
    
    driver = ogr.GetDriverByName('ESRI Shapefile')
    dataSource = driver.Open(points, 0)
    layer = dataSource.GetLayer()
    
    deer_list = []
    for deer in layer:
        agent = Deer(deer)
        deer_list.append(agent)
        
    return deer_list

def success_rate(success_log, total_iterations):
    """
    Determines success rate of dispersals from points
    success_log: dictionary of success (True/False) from each point (keys)
    total_iterations: number of dispersals from each point
    """
    points = list(success_log.keys())
    rates = []
    for set in success_log.values():
        success_count = 0
        for dispersal in set:
            if set[dispersal]:
                success_count +=1
        rate = success_count / total_iterations
        rates.append(rate)
    success_rates = dict(zip(points,rates))
    
    return success_rates
    

    
    
    
    

