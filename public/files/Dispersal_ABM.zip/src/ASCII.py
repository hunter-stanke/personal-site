'''
------------ SPECIFICATION ------------------------------------
AUTHOR: Arika Ligmann-Zielinska
CREATED ON: August 27, 2006
LAST UPDATED: Apr 2018

DESRCIPTION
   Handles ASCII raster objects, requires numpy
This Raster class does NOT handle multiple raster datasets!
'''
#----------- FUNCTIONS ----------------------------------------
import numpy as np
import os.path

class Raster(object):

    def __init__(self,asciifile,datatype=int):
        """
        ASCII grid file, (datatype = int, float)
              
        Attributes:
            name            raster name
            type            raster type (int or float)
            header          ASCII grid header in raw format (one string)
            nclos           int, number of grid columns
            nrows           int, number of grid rows
            bb_Xmin         float, min value of X coordinate of the bbox
            bb_Xmax         float, max value of X coordinate of the bbox
            bb_Ymin         float, min value of Y coordinate of the bbox
            bb_Ymax         float, max value of Y coordinate of the bbox
            cellsize        int, the size of the cell in map units
            NODATA_value    int, value of missing data
            body            the content of the grid (numpy array)
            domain          for int rasters: exhaustive and exclusive list of raster body values
            read_or_write   allows update of values in raster file
        """
        if not os.path.exists(asciifile):
            raise IOError("File "+asciifile+" does not exist.")
        self.type = datatype
        self.name = os.path.basename(asciifile)[:-4]
        try:
            # header
            with open(asciifile,'r') as f:
                hdata = f.readlines()[:6]
            self.header = ''.join(hdata)[:-1]
            self.ncols = int(hdata.pop(0).strip().split()[1])
            self.nrows = int(hdata.pop(0).strip().split()[1])
            self.BB_Xmin = float(hdata.pop(0).strip().split()[1])
            self.BB_Ymin = float(hdata.pop(0).strip().split()[1])
            self.cellsize = int(hdata.pop(0).strip().split()[1])
            self.BB_Xmax = self.BB_Xmin+self.cellsize*float(self.ncols)
            self.BB_Ymax = self.BB_Ymin+self.cellsize*float(self.nrows)
            self.NODATA_value = int(hdata.pop(0).strip().split()[1])
            # body
            self.body = np.loadtxt(asciifile, dtype=datatype, skiprows=6)
            self.domain = None
            if datatype == int:
                self.domain = set(self.body.flatten())
        except IOError:
            print("Inappropriate file format.")

    def __str__(self):
        label = "name\t"+self.name+"\nrows\t"+str(self.nrows)+\
                "\ncols\t"+str(self.ncols)+\
                "\ncellsize\t"+str(self.cellsize)+\
                "\nvalue list\t"+\
                str(self.domain)+"\n"
        return label
    
    def save(self, out_name, confirm=True):
        """
        Saves Raster body to out_name file
        confirm(bool) print confirmation message (default true)
        """
        np.savetxt(out_name, self.body, fmt ='%.2f', header=self.header, comments='')
        if confirm:
            print("File",out_name,"saved.")

    def grid_loc_to_xy(self,row,col):
         """
         Converts input location in row, col to geographic coordinates.
         Returns X,Y pair.
         """
         ycoord = self.BB_Ymax - row*float(self.cellsize)
         xcoord = col*float(self.cellsize) + self.BB_Xmin
         return (xcoord,ycoord)
     
    def xy_to_grid_loc(self,xcoord,ycoord):
        """
        Converts input location in geographic coordinates to row and col.
        Returns row,col pair.
        """
        row = int((self.BB_Ymax-ycoord)/float(self.cellsize))
        col = int((xcoord-self.BB_Xmin)/float(self.cellsize))
        return (row,col)

    def value_at_row_col(self, row, col):
        """
        Retrieves the value at row and col
        OUT: number (float, int) or NODATA
        """
        if (0 <= row and row < self.nrows) and (0 <= col and col < self.ncols):
            return self.body[row,col]
        else:
            print("WARNING: Out of raster bounds, returning NoData")
            return self.NODATA_value

    def value_at_xy(self,xcoord,ycoord):
        """
        Retrieves the value at geographic location: xcoord, ycoord
        OUT: number (float, int) or NODATA 
        """
        # to obtain value at true projected coordinates
        # we need to convert these geo-coordinates into the
        # numpy array indices so that we can read the corresponding 
        # value of the 'body' attribute
        row = int((self.BB_Ymax-ycoord)/float(self.cellsize))
        col = int((xcoord-self.BB_Xmin)/float(self.cellsize))
        if (0 <= row and row < self.nrows) and (0 <= col and col < self.ncols):
            return self.body[row,col]
        else:
            print("WARNING: Out of raster bounds, returning NoData")
            return self.NODATA_value
        
    def neighbors3x3(self,focal_row, focal_col): 
        ''' 
        for a 3x3 neighborhood of an input (row, col) location:
            returns an array where:
                1st row are neighbors' indices of rows
                2nd row are neighbors' indices of cols
            in:
                focal_row    row for the cell in the center of 3x3 neighborhood (int)
                focal_col    col for the cell in the center of 3x3 neighborhood (int)
        NOTE: indices of the focal cell are included in the output
        '''
        r_min = focal_row - 1
        r_max = focal_row + 1
        c_max = focal_col + 1
        c_min = focal_col - 1
        if r_min < 0: # boundary cells have either 4 cells or 6 cells in their neighborhood
            r_min = 0
        if r_max > self.nrows-1: 
            r_max = self.nrows-1
        if c_min < 0: 
            c_min = 0
        if c_max > self.ncols-1: 
            c_max = self.ncols-1
        ncoords = [(nrow,ncol) for nrow in range(r_min,r_max+1) for ncol in range(c_min,c_max+1)]
        return np.array(ncoords).T
     
    def get_neighborhood_values(self,row,col):
        """
        Retrieves values for the 3x3 neighborhood at input row, col
        OUT: 1D value array of len up to 9 (smaller for boundary cells)
        """
        nrows, ncols = self.neighbors3x3(row,col)
        return self.body[nrows,ncols]
    
