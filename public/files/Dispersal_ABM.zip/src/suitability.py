# -*- coding: utf-8 -*-
"""
Created on Mon Apr  2 12:34:23 2018

GEO869 ~ Geosimulation

Final Project Code

Hunter Stanke

"""
import math
import random


#Parameter values for distance decay function
#values obtained by fitting exponential decay model from NY movement data
a = 2.61573
b = -0.01421


#Probability of movement through land cover types  (movement through forest (p = 1))

ag_prob = .8            #Class: 20, Agricuture/ Range
emergent_prob = .8      #Class: 65, Emergent Wetland
low_urban_prob = .5     #Class: 25, Low Level Urban Development
high_urban_prob = .15   #Class: 75, High Level Urban Development
water_prob = .05        #Class: 95, Open water


def suitability_forest(cell_row, cell_col, forest_layer):
    
    '''
    Defines the suitability of a cell for deer movement based solely on its distance to forest
    If a cell is forested or adjacent to forest, then the cell is suitable for movement
    If a cell is not forested or adjacent to forest, then the probability of that cell being suitable for movement decreases
        as a function of its distance from forest. Suitability is tested by drawing a random number between 0 and 1 and 
        comparing the value of this random draw the probability of movement defined by the distance decay function. If the 
        random value is less than that of the probability of movement, the cell is suitable. If the random value is greater, 
        the cell is unsuitable
    
    forest_layer: distance to forest layer. Defines euclidean distance to forest for all cells in raster
    
    returns suitability (TRUE or FALSE) 
    '''
    global suitable
    
    for_index = forest_layer.value_at_row_col(cell_row, cell_col)
    
    if for_index < 130:   # If cell is forested or adjacent to forest, it is suitable for movement
        suitable = True                         
    else: # If cell is not adjacent to forested cell, the probability of movement cell decreases with distance from forest
        draw = random.random()
        suit_prob = a * math.exp(b * for_index)  #Distance decay function
        if draw < suit_prob:
            suitable = True
        else:
            suitable = False
    
    return suitable



def suitability_lulc(cell_row, cell_col, lulc_layer):
    
    """
    Defines suitability of cell based solely on land cover/ land use type
    
    Suitability determined by comparing random draw to probability of movement through cover type
    
    lulc_layer: discrete raster with interger values representing land cover types
    
    returns suitability (TRUE or FALSE) 
    
    """
    global suitable
    
    lulc_index = lulc_layer.value_at_row_col(cell_row, cell_col)
    
    if lulc_index == 1: #forested
        suitable = True
        
    if lulc_index == 2: # Agriculture/ Range
        draw = random.random()
        if draw < ag_prob:
            suitable = True
        else:
            suitable = False
            
    if lulc_index == 3: # Emergent Wetland
        draw = random.random()
        if draw < emergent_prob:
            suitable = True
        else:
            suitable = False
            
    if lulc_index == 4: # Low Level urban Development
        draw = random.random()
        if draw < low_urban_prob:
            suitable = True
        else:
            suitable = False
            
    if lulc_index == 5: # High Level urban development
        draw = random.random()
        if draw < high_urban_prob:
            suitable = True
        else:
            suitable = False
    
    if lulc_index == 6: # Open water
        draw = random.random()
        if draw < water_prob:
            suitable = True
        else:
            suitable = False
    
    if lulc_index == 0: # NoData
        suitable = False
        
        
    return suitable




