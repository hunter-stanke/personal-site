# -*- coding: utf-8 -*-
"""
Created on Tue Apr 24 11:29:11 2018

@author: hstan
"""

def step(deer_list, forest, ccap):
    
    for ag in deer_list:
        neighbors = ag.neighborhood(ccap) # Requires raster input for indexing
        ag.move(neighbors, forest_layer = forest, lulc_layer = ccap)
