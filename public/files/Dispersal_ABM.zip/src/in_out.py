# -*- coding: utf-8 -*-
"""
Created on Wed Apr 18 11:46:01 2018

GEO869 ~ Geosimulation

Final Project Code

Hunter Stanke and Yachen Xie

    Scripts allows for importing and exporting of raster files other than ASCII
"""

import sys
from osgeo import gdal

def read_array(raster_file):
    '''
    Reads raster files and coverts to numpy arrays
    raster_file: File path, tif recommended
    '''
    ds = gdal.Open(raster_file)
    if ds is None:
        print ('Could not open image file')
        sys.exit(1)
    
    bands = ds.GetRasterBand(1)
    rows = ds.RasterYSize
    cols = ds.RasterXSize
    data = bands.ReadAsArray(0,0,cols,rows)
    
    return data



def out_tif(array_to_output, reference_raster, out_file):
    '''
    Uses GDAL to produce output file from array
    reference_raster: determines projection and geotransform for output raster
    out_file: file path to output
    '''
    gdal.AllRegister()
    
    # open the image for test
    inDs = gdal.Open(reference_raster)
    if inDs is None:
        print('Could not open image file')
        sys.exit(1)
    
    # read in the image
    #band1 = inDs.GetRasterBand(1)
    rows = inDs.RasterYSize
    cols = inDs.RasterXSize
    #data = band1.ReadAsArray(0,0,cols,rows)
    
    
    # create the output image
    driver = inDs.GetDriver()
    #print driver
    outDs = driver.Create(out_file, cols, rows, 1, gdal.GDT_Float32)
    if outDs is None:
        print('Could not create file')
        sys.exit(1)
    
    outBand = outDs.GetRasterBand(1)
                
            
    #outDs.GetRasterBand(1).WriteArray(array)
    # write the data
    outBand.WriteArray(array_to_output, 0, 0)
    
    # flush data to disk, set the NoData value and calculate stats
    outBand.FlushCache()
    outBand.SetNoDataValue(-9999)
    
    # georeference the image and set the projection
    
    outDs.SetGeoTransform(inDs.GetGeoTransform())
    outDs.SetProjection(inDs.GetProjection())
    
    del array_to_output
    outBand=None
    outDs=None



