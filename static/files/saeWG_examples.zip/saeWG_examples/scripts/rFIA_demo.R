library(rFIA)
library(ggplot2)





##===============================================================================
##  Install rFIA ----------------------------------------------------------------
##===============================================================================

## From CRAN
install.packages('rFIA')

## From GitHub
devtools::install_github('hunter-stanke/rFIA')

## Attach package
library(rFIA)






##===============================================================================
##  Download FIA data -----------------------------------------------------------
##===============================================================================

## Directory where I store FIA data
fiaDir <- 'C:/Users/hstan/Dropbox/FIA'
list.files(fiaDir)


## Download, but don't load it in yet
getFIA(states = c('RI'), dir = fiaDir, load = FALSE)


## Read it into memory
ri <- readFIA('C:/Users/hstan/Dropbox/FIA', states = 'RI')






##===============================================================================
##  Basic post-stratified estimators --------------------------------------------
##===============================================================================

## Simple time-series -----------------------------------------------------------

## TPA & BAA - 4 ratio estimates & SE and 15 reporting years
riTPA <- tpa(ri)
riTPA
plotFIA(riTPA, y = TPA, x = YEAR)

## Also see `totals`, `variance`, and `nCores` arguments








## Grouped (condition/domain) estimates -----------------------------------------
riOWN <- tpa(ri, grpBy = OWNGRPCD)
riOWN
plotFIA(riOWN, y = TPA, x = YEAR, grp = OWNGRPCD)

## Also see `bySpecies` and `bySizeClass` arguments











## Unique populations of interest -----------------------------------------------
## Only "high" productivity sites
tpa(ri, areaDomain = SITECLCD <= 4)

## Only "large" trees on those sites
tpa(ri, areaDomain = SITECLCD <= 4, treeDomain = DIA > 12)











## Spatial units ----------------------------------------------------------------
plot(countiesRI)
riSF <- tpa(ri, polys = countiesRI, returnSpatial = TRUE)
plotFIA(riSF, y = TPA, animate = TRUE)













## Space-time queries -----------------------------------------------------------

## Most recent subset
riMR <- clipFIA(ri, mostRecent = TRUE)

tpa(riMR)










## Plot-level estimates ---------------------------------------------------------

## Plots associated with most recent inventory
riPlt <- tpa(riMR, byPlot = TRUE)
riPlt

## Add spatial info
riPlt <- tpa(riMR, byPlot = TRUE, returnSpatial = TRUE)
riPlt
plotFIA(riPlt, y = BAA, legend.height = .75)






##===============================================================================
##  A VERY simple small area estimator ------------------------------------------
##===============================================================================

## Some climate data (MAT) from PRISM
plot(mat)

## Get climate values at each plot location 
riPlt <- st_intersection(riPlt, mat)

## Build our "design matrix" --------------------------------------------
ref <- riPlt %>%
  as.data.frame() %>%
  ## When we encounter more than one plot in a cell, aggregate them to one
  group_by(cellID) %>%
  summarise_all(.funs = mean) %>%
  ungroup() %>%
  filter(!is.na(cellID))


## World's worst small area estimator ------------------------------------

## OLS
mod <- lm(BAA ~ MAT, data = ref)

## Prediction to all pop units
preds <- predict(mod, mat, se.fit = TRUE)

## Make them spatial
mat$pred <- preds$fit
mat$se <- preds$se








## Pretty plots
baa <- mat %>%
  ggplot() +
  geom_sf(aes(fill=pred), colour = NA)+
  scale_fill_viridis_c(guide = guide_colorbar(title = 'Predicted\nBAA')) +
  theme_minimal() +
  theme(axis.text = element_blank(),
        axis.ticks = element_blank(),
        panel.grid = element_blank())

se <- mat %>%
  ggplot() +
  geom_sf(aes(fill=se), colour = NA)+
  scale_fill_viridis_c(guide = guide_colorbar(title = 'Standard\nError'),
                       option = 'A') +
  theme_minimal() +
  theme(axis.text = element_blank(),
        axis.ticks = element_blank(),
        panel.grid = element_blank())

gridExtra::grid.arrange(baa, se, nrow = 1)
